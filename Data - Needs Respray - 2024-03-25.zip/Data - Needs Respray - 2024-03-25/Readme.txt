Needs Respray Dataset
---------------------

IMPORTANT: The following dataset is part of Berrijam Jam 2024 and released for use by participants of the Berrijam Jam 2024. Use outside of the competition requires permission from Berrijam which can be obtained by emailing jam@berrijam.com. 

The folder contains twp types of files:
1. PNG files of pavers
2. Labels-NeedsRespray-2024-03-25.csv contains the labels for the corresponding png file denoting if it needs a re-spray of weed killer.

Each image file is 1200 x 900 pixel. 
